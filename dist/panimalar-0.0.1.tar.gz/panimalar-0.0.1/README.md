# Panimalar

A package for students of Panimalar Engineering College

## Modules

- Validate Roll Number

- Parse Details from Roll Number

Roll Number in Panimalar follows the system (YEAROFJOIN)YYYY-PEC-(DEPT)DD-(ROLLNO)XXXX

eg) 2021PECCB101

2021 - Year of Join
PEC - Panimalar Engineering College
CB - Department (Computer Science and Business Systems)
101 - Roll Number of Student
